Dentro de esta carpeta se encuentran los archivos.sh. Para que todo funcione correctamente, se debe ubicar en la siguiente 
carpeta:

/home/administrador/Desktop/CRONTAB

El contenido de la carpeta debe permanecer allí o el programa no funcionará.

Para iniciar con el programa, ejecute el siguiente comando:

sh permisosCrontab.sh

Los respaldos se ubicarán en una carpeta dentro del directorio de trabajo que se llama "Respaldo-" y la fecha en la que 
se creó. 
