find /home/administrador/ -type d -name 'Respaldo-*' -exec sh -c '
  for dir do
    backup_date=$(basename "$dir" | cut -d- -f2-4)
    if [ "$(date -d "$backup_date" +%u)" -eq 5 ]; then
      if [ "$(date -d "$backup_date" +%d)" -lt "$(date -d "$(date -d "$backup_date +1 month" +%Y-%m-01) -1 day" +%d)" ]; then
        rm -rf "$dir"
      fi
    fi
  done
' sh {} +
