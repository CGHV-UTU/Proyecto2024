find /home/administrador/ -type d -name 'Respaldo-*' -exec sh -c '
  for dir do
    if [ "$(date -d "$(basename "$dir" | cut -d- -f2-4)" +%u)" -ne 5 ]; then
      rm -rf "$dir"
    fi
  done
' sh {} +
