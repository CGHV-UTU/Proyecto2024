DIRECTORY="/home/santiago/Respaldo-$(date +%Y-%m-%d)"
mkdir -p "$DIRECTORY"
cd "$DIRECTORY"
mysqldump --databases base > Backup.sql
mysqldump --databases base > Backup.txt
echo "Fin del backup: " $(date +%H:%M:%S) > Backup.txt
cd -
