sudo dnf install cron
chmod ugo+rwx backup.sh
#chmod ugo+rwx backupDir.sh
chmod ugo+rwx cleanDaily.sh
chmod ugo+rwx cleanWeekly.sh
chmod ugo+rwx cleanMonthly.sh
crontab comandos
