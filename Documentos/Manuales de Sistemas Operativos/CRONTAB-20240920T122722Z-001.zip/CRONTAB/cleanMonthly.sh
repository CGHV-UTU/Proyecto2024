# clean_monthly.sh
find /home/administrador/ -type d -name 'Respaldo-*' -exec sh -c '
  for dir do
    backup_date=$(basename "$dir" | cut -d- -f2-4)
    if [ "$(date -d "$backup_date" +%d)" -eq 28 ]; then
      if [ "$((($(date -d "$backup_date" +%m) % 3) + 1))" -ne 0 ]; then
        rm -rf "$dir"
      fi
    fi
  done
' sh {} +
